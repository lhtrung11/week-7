public abstract class Expression {
    abstract double evaluate();
    public abstract String toString();
}
