public class Addition extends  BinaryExpression {
    public Addition( Expression l, Expression r){
        super(l,r);
    }
}
