public class Numeral extends Expression {
    protected double value;
    public Numeral( double v){
        value = v;
    }
    public Numeral(){

    }
    public double evaluate(){
        return 0;
    }
    public String toString(){
        return "";
    }
}
