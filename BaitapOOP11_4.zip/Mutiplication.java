public class Mutiplication {
}
