public class Divide {
}
