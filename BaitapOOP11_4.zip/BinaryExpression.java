public class BinaryExpression extends Expression {
    protected Expression left;
    protected Expression right;
    public BinaryExpression( Expression l, Expression r){
        left = l;
        right = r;
    }
    public double evaluate(){
        return 0;
    }
    public String toString(){
        return "";
    }
}
